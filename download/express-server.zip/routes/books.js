const router = global.express.Router();
const books = global.mocks.books;

router.post('/', function(request, response) {
  books.push(request.body);
  console.log('Done books post', books);
  response.status(200).send({
    result: 'Created'
  });
});

router.get('/', function(request, response) {
  console.log('Done books get', books);
  response.status(200).send({
    result: 'Readed',
    books: books
  });
});

router.patch('/', function(request, response) {
  books[request.body.index] = request.body.book;
  console.log('Done books patch', books);
  response.status(200).send({
    result: 'Updated'
  });
});

router.delete('/:index', function(request, response) {
  const index = Number(request.params.index);
  books.splice(index, 1);
  console.log('Done books delete', books);
  response.status(200).send({
    result: 'Deleted'
  });
});

module.exports = router;
