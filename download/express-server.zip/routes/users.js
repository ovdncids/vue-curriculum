const users = require('../mocks/users.json')
const express = require('express')
const router = express.Router()

router.post('/', function(request, response) {
  users.push(request.body)
  console.log('Done users post', users)
  response.status(200).send({
    result: 'Created'
  })
})

router.get('/', function(request, response) {
  console.log('Done users get', users)
  response.status(200).send({
    result: 'Read',
    users: users
  })
})

router.patch('/:index', function(request, response) {
  const index = Number(request.params.index)
  users[index] = request.body
  console.log('Done users patch', users)
  response.status(200).send({
    result: 'Updated'
  })
})

router.delete('/:index', function(request, response) {
  const index = Number(request.params.index)
  users.splice(index, 1)
  console.log('Done users delete', users)
  response.status(200).send({
    result: 'Deleted'
  })
})

module.exports = router
