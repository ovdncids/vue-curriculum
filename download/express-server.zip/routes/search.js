const router = global.express.Router();
const books = global.mocks.books;

router.get('/', function(request, response) {
  const q = request.query.q;
  const searchBooks = [];
  for (let index = 0; index < books.length; index++) {
    if (!q || books[index].name.indexOf(q) >= 0) {
      searchBooks.push(books[index]);
    }
  }
  console.log('Done search get', searchBooks);
  response.status(200).send({
    result: 'Searched',
    books: searchBooks
  });
});

module.exports = router;
