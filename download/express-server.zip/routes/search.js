const users = require('../mocks/users.json')
const express = require('express')
const router = express.Router()

router.get('/', function(request, response) {
  const q = request.query.q || ''
  const searchUsers = []
  for (let index = 0; index < users.length; index++) {
    if (users[index].name.includes(q)) {
      searchUsers.push(users[index])
    }
  }
  console.log('Done search get', searchUsers)
  response.status(200).send({
    result: 'Searched',
    users: searchUsers
  })
})

module.exports = router
