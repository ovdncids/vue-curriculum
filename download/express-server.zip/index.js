const express = require('express')
const app = express()

// Swagger
const swaggerUi = require('swagger-ui-express')
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(require('./swagger.json')))

// CORS, Methods, Headers
app.use(function(request, response, next) {
  response.setHeader('Access-Control-Allow-Origin', '*')
  response.setHeader('Access-Control-Allow-Methods', 'OPTIONS, PUT, PATCH, DELETE')
  response.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  next()
})

// API router
app.use(express.json())
app.use('/api/v1/users', require('./routes/users.js'))
app.use('/api/v1/search', require('./routes/search.js'))

// Start server
app.listen(3100, function() {
  console.log('Express server listening on http://localhost:3100/api/v1/users')
  console.log('Swagger on http://localhost:3100/api-docs')
})
