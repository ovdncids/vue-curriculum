<template>
  <div id="app">
    <header>
      <h1>Vue.js study</h1>
    </header>
    <hr />
    <div class="container">
      <nav class="nav">
        <ul>
          <li><h2>Members</h2></li>
          <li><h2>Search</h2></li>
        </ul>
      </nav>
      <hr />
      <section class="contents">
        <DatePicker :fromDates="fromDates"></DatePicker>
      </section>
      <hr />
    </div>
    <footer>
      Copyright
      {{fromDates}}
    </footer>
  </div>
</template>

<script>
import moment from 'moment'
import DatePicker from './components/DatePicker.vue'

export default {
  components: {
    DatePicker
  },
  data() {
    return {
      fromDates: {
        startDate: moment().format('YYYY-MM-DD'),
        endDate: moment().add(2, 'weeks').format('YYYY-MM-DD')
      }
    }
  }
}
</script>
