<template>
  <div>
    {{currentYearMonth}}
    <!-- <button @click="fromDates.startDate = '2021-01-01'">2021-01-01</button> -->
    <div>
      <table>
        <thead>
          <tr>
            <th>Sun</th>
            <th>Mon</th>
            <th>Tue</th>
            <th>Wen</th>
            <th>Thu</th>
            <th>Fri</th>
            <th>Sat</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="line in 5" :key="line">
            <td v-for="day in 7" :key="day">{{calcDay(line, day)}}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import moment from 'moment'

export default {
  props: {
    fromDates: Object,
    dpData: Object,
    isFirstCalendar: Boolean
  },
  computed: {
    currentYearMonth() {
      return this.isFirstCalendar
        ? this.dpData.selectedYearMonth
        : moment(this.dpData.selectedYearMonth).add(1, 'months').format('YYYY-MM')
    },
    firstDay() {
      return moment(this.currentYearMonth).startOf('month')
    }
  },
  methods: {
    calcDay(line, day) {
      const calc = (line - 1) * 7 + (day - 1) - this.firstDay.day()
      return moment(this.firstDay).add(calc, 'days').format('D')
    }
  },
  created() {
    console.log('move')
  }
}
</script>
