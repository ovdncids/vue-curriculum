<template>
  <div>
    <input v-model="fromDates.startDate" @click="dpData.showDatePicker = !dpData.showDatePicker">
    ~ 
    <input v-model="fromDates.endDate" @click="dpData.showDatePicker = !dpData.showDatePicker">
    <div v-if="dpData.showDatePicker">
      <button @click="moveMonths(-1)">-1</button>
      <button @click="moveMonths(1)">1</button>
      <div class="date-picker-pair-calendar">
        <Calendar :fromDates="fromDates" :dpData="dpData" :isFirstCalendar="true"></Calendar>
        <Calendar :fromDates="fromDates" :dpData="dpData"></Calendar>
      </div>
    </div>
  </div>
</template>

<script>
import moment from 'moment'
import Calendar from './Calendar.vue'

export default {
  components: {
    Calendar
  },
  props: {
    fromDates: Object
  },
  data() {
    return {
      dpData: {
        showDatePicker: false,
        selectedYearMonth: moment(this.fromDates.startDate).format('YYYY-MM')
      }
    }
  },
  watch: {
    'dpData.showDatePicker': function(showDatePicker) {
      if (showDatePicker) {
        this.dpData.selectedYearMonth = moment(this.fromDates.startDate).format('YYYY-MM')
      }
    }
  },
  methods: {
    moveMonths(value) {
      this.dpData.selectedYearMonth = moment(this.dpData.selectedYearMonth).add(value, 'months').format('YYYY-MM')
      console.log(this.dpData.selectedYearMonth)
    }
  }
}
</script>

<style>
.date-picker-pair-calendar {
  display: flex;
}
</style>
