const express = require('express');
const router = express.Router();
const _ = require('lodash');
const members = process.mocks.members;

router.get('/', function(request, response) {
  const name = request.query.name;
  let sMembers = members;
  if (name) {
    sMembers = _.filter(members, function(member) {
      return member.name.indexOf(name) >= 0;
    });
  }
  response.status(200).send({
    result: 'Success',
    members: sMembers
  });
});

module.exports = router;
