const express = require('express');
const router = express.Router();
const _ = require('lodash');
const members = process.mocks.members;

router.get('/', function(req, res) {
  const name = req.query.name;
  let sMembers = members;
  if (name) {
    sMembers = _.filter(members, function(member) {
      return member.name.indexOf(name) >= 0;
    });
  }
  res.status(200).send({
    result: 'Success',
    members: sMembers
  });
});

module.exports = router;
