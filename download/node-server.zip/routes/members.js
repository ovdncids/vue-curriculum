const express = require('express');
const router = express.Router();
const moment = require('moment');
const members = process.mocks.members;

router.post('/', function(request, response) {
  const member = request.body;
  member.createdDate = moment().format();
  members.push(member);
  console.log(members);
  response.status(200).send({
    result: 'Created'
  });
});

router.get('/', function(request, response) {
  response.status(200).send({
    result: 'Readed',
    members: members
  });
});

router.patch('/', function(request, response) {
  members[request.body.index].name = request.body.member.name;
  members[request.body.index].age = request.body.member.age;
  console.log(members);
  response.status(200).send({
    result: 'Updated'
  });
});

router.delete('/:index', function(request, response) {
  const index = Number(request.params.index);
  members.splice(index, 1);
  console.log(members);
  response.status(200).send({
    result: 'Deleted'
  });
});

module.exports = router;
