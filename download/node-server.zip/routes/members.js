const express = require('express');
const router = express.Router();
const moment = require('moment');
const members = process.mocks.members;

router.post('/', function(request, response) {
  const member = request.body;
  member.createdDate = moment().format();
  members[members.length] = request.body;
  console.log(members);
  response.status(200).send({
    result: 'Created'
  });
});

router.get('/', function(request, response) {
  response.status(200).send({
    result: 'Readed',
    members
  });
});

router.put('/', function(request, response) {
  members[request.body.key].name = request.body.member.name;
  members[request.body.key].age = request.body.member.age;
  console.log(members);
  response.status(200).send({
    result: 'Updated'
  });
});

router.delete('/:key', function(request, response) {
  const key = Number(request.params.key);
  members.splice(key, 1);
  console.log(members);
  response.status(200).send({
    result: 'Deleted'
  });
});

module.exports = router;
