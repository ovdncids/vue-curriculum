import Vue from 'vue'
import VueRouter from 'vue-router'
import Users from '../components/contents/UsersComponent.vue'
import Search from '../components/contents/SearchComponent.vue'

Vue.use(VueRouter)

const routes = [
  { path: '/', redirect: '/users' },
  {
    path: '/users',
    name: 'Users',
    component: Users
  },
  {
    path: '/search',
    name: 'Search',
    component: Search
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
