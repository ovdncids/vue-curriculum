<template>
  <header>
    <h1>Vue.js study</h1>
  </header>
</template>
