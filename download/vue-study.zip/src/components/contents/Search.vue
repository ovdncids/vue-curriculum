<template>
  <div>
    <h3>Search</h3>
    <hr class="d-block" />
    <div>
      <input type="text" placeholder="Search" v-model="search" @keyup="keyUp($event)" />
      <button @click="searchRead()">Search</button>
    </div>
    <hr class="d-block" />
    <div>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Age</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(member, key) in members" :key="key">
            <td>{{member.name}}</td>
            <td>{{member.age}}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      search: ''
    }
  },
  watch: {
    '$route.query': function(query, beforeQuery) {
      console.log(query, beforeQuery)
      this.search = query.search || ''
      this.$store.dispatch('searchRead', this.search)
    }
  },
  computed: {
    members() {
      return this.$store.state.members.members
    }
  },
  methods: {
    keyUp($event) {
      if ($event.key === 'Enter') this.searchRead()
    },
    searchRead() {
      this.$router.push({ name: 'Search', query: { search: this.search }})
    }
  },
  created() {
    this.search = this.$route.query.search || ''
    this.$store.dispatch('searchRead', this.search)
  }
}
</script>
