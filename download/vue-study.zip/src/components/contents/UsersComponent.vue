<template>
  <div>
    <h3>Users</h3>
    <hr class="d-block" />
    <div>
      <h4>Read</h4>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Age</th>
            <th>Modify</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(user, index) in users" :key="index">
            <td><input type="text" placeholder="Name" v-model="user.name" /></td>
            <td><input type="text" placeholder="Age" v-model="user.age" /></td>
            <td>
              <button @click="usersUpdate(index, user)">Update</button>
              <button @click="usersDelete(index)">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <hr class="d-block" />
    <div>
      <h4>Create</h4>
      <input type="text" placeholder="Name" v-model="user.name" />
      <input type="text" placeholder="Age" v-model="user.age" />
      <button @click="usersCreate(user)">Create</button>
    </div>
  </div>
</template>

<script>
export default {
  computed: {
    user() {
      return this.$store.state.$users.user
    },
    users() {
      return this.$store.state.$users.users
    }
  },
  methods: {
    usersCreate(user) {
      this.$store.dispatch('usersCreate', user)
    },
    usersDelete(index) {
      this.$store.dispatch('usersDelete', index)
    },
    usersUpdate(index, user) {
      this.$store.dispatch('usersUpdate', { index, user })
    }
  },
  created() {
    this.user.name = ''
    this.user.age = ''
    this.$store.dispatch('usersRead')
  }
}
</script>
