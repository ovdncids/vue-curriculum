import Vue from 'vue'
import Vuex from 'vuex'
import { membersModule } from './membersModule.js'
import { searchModule } from './searchModule.js'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
  },
  getters: {
  },
  mutations: {
  },
  actions: {
    axiosError(thisStore, error) {
      console.error(error.response || error.message || error)
    }
  },
  modules: {
    $members: membersModule,
    $search: searchModule
  }
})
