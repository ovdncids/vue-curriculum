import axios from 'axios'

export const moduleSearch = {
  actions: {
    searchRead(thisStore, search) {
      const url = '/api/v1/search?search=' + search
      axios.get(url).then(function(response) {
        console.log('Done searchRead', response)
        thisStore.commit('membersRead', response.data.members)
      }).catch(function(error) {
        thisStore.dispatch('axiosError', error)
      })
    }
  }
}
