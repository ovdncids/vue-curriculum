import axios from 'axios'

export const usersModule = {
  state: {
    users: [],
    user: {
      name: '',
      age: ''
    }
  },
  mutations: {
    usersRead(state, users) {
      state.users = users
    }
  },
  actions: {
    usersCreate(thisStore, user) {
      axios.post('http://localhost:3100/api/v1/users', user).then(function(response) {
        console.log('Done usersCreate', response)
        thisStore.dispatch('usersRead')
      }).catch(function(error) {
        thisStore.dispatch('axiosError', error)
      })
    },
    usersRead(thisStore) {
      axios.get('http://localhost:3100/api/v1/users').then(function(response) {
        console.log('Done usersRead', response)
        thisStore.commit('usersRead', response.data.users)
      }).catch(function(error) {
        thisStore.dispatch('axiosError', error)
      })
    },
    usersDelete(thisStore, index) {
      axios.delete('http://localhost:3100/api/v1/users/' + index).then(function(response) {
        console.log('Done usersDelete', response)
        thisStore.dispatch('usersRead')
      }).catch(function(error) {
        thisStore.dispatch('axiosError', error)
      })
    },
    usersUpdate(thisStore, { index, user }) {
      axios.patch('http://localhost:3100/api/v1/users/' + index, user).then(function(response) {
        console.log('Done usersUpdate', response)
        thisStore.dispatch('usersRead')
      }).catch(function(error) {
        thisStore.dispatch('axiosError', error)
      })
    }
  }
}
