<template>
  <div>
    <footer>{{title}}</footer>
  </div>
</template>

<script>
export default {
  props: {
    title: {
      default: 'Rightcopy'
    }
  }
}
</script>

<style lang="scss">
</style>
